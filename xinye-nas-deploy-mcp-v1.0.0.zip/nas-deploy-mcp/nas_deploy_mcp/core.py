"""Safe, allow-listed deployment operations for the Xinye NAS target."""

from __future__ import annotations

import datetime as dt
import json
import os
import posixpath
import re
import shutil
import subprocess
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

MAX_OUTPUT = 12_000
BACKUP_PATTERN = re.compile(r"^\.backup-[A-Za-z0-9_.-]+$")
SERVICE_NAMES = {"backend", "frontend", "all"}


def clip(value: str, limit: int = MAX_OUTPUT) -> str:
    """Keep tool responses bounded while retaining the beginning and end."""
    if len(value) <= limit:
        return value
    head = limit * 2 // 3
    return value[:head] + "\n...[truncated]...\n" + value[-(limit - head - 22):]


@dataclass(frozen=True)
class Settings:
    """Runtime configuration loaded from environment variables."""

    host: str
    ssh_port: int
    username: str
    password: str
    private_key: str
    deploy_dir: str
    http_url: str
    project_root: Path
    ssh_timeout: int
    build_timeout: int
    pnpm_bin: str
    known_hosts: str
    strict_host_key: bool

    @classmethod
    def from_env(cls) -> "Settings":
        root_value = os.getenv("PROJECT_ROOT", "").strip()
        root = Path(root_value) if root_value else Path(__file__).resolve().parents[3]
        return cls(
            host=os.getenv("NAS_HOST", "").strip(),
            ssh_port=int(os.getenv("NAS_SSH_PORT", "22")),
            username=os.getenv("NAS_USERNAME", "").strip(),
            password=os.getenv("NAS_PASSWORD", ""),
            private_key=os.getenv("NAS_PRIVATE_KEY", "").strip(),
            deploy_dir=os.getenv("NAS_DEPLOY_DIR", "/volume1/docker/xinye-workhours").strip(),
            http_url=os.getenv("NAS_HTTP_URL", "http://192.168.112.188:8088").rstrip("/"),
            project_root=root,
            ssh_timeout=int(os.getenv("NAS_SSH_TIMEOUT", "20")),
            build_timeout=int(os.getenv("NAS_BUILD_TIMEOUT", "900")),
            pnpm_bin=os.getenv("PNPM_BIN", "").strip(),
            known_hosts=os.getenv("NAS_KNOWN_HOSTS", "").strip(),
            strict_host_key=os.getenv("NAS_STRICT_HOST_KEY", "false").lower() in {"1", "true", "yes"},
        )

    def validate(self) -> None:
        """Validate required settings before opening an SSH connection."""
        missing = [name for name, value in (("NAS_HOST", self.host), ("NAS_USERNAME", self.username)) if not value]
        if not self.password and not self.private_key:
            missing.append("NAS_PASSWORD or NAS_PRIVATE_KEY")
        if missing:
            raise ValueError("Missing MCP configuration: " + ", ".join(missing))
        if not self.deploy_dir.startswith("/") or "\n" in self.deploy_dir:
            raise ValueError("NAS_DEPLOY_DIR must be an absolute POSIX path")
        if not 1 <= self.ssh_port <= 65535:
            raise ValueError("NAS_SSH_PORT must be between 1 and 65535")


class NasClient:
    """SSH/SFTP adapter with commands restricted to the configured project."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client: Any | None = None

    def __enter__(self) -> "NasClient":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        if self.client is not None:
            self.client.close()
            self.client = None

    def connect(self) -> None:
        self.settings.validate()
        try:
            import paramiko
        except ImportError as exc:
            raise RuntimeError("paramiko is not installed; run the MCP installer first") from exc
        client = paramiko.SSHClient()
        if self.settings.known_hosts:
            client.load_host_keys(self.settings.known_hosts)
            client.set_missing_host_key_policy(paramiko.RejectPolicy())
        elif self.settings.strict_host_key:
            client.load_system_host_keys()
            client.set_missing_host_key_policy(paramiko.RejectPolicy())
        else:
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        args: dict[str, Any] = {
            "hostname": self.settings.host,
            "port": self.settings.ssh_port,
            "username": self.settings.username,
            "timeout": self.settings.ssh_timeout,
            "banner_timeout": self.settings.ssh_timeout,
            "auth_timeout": self.settings.ssh_timeout,
            "look_for_keys": not bool(self.settings.password),
            "allow_agent": not bool(self.settings.password),
        }
        if self.settings.private_key:
            args["key_filename"] = self.settings.private_key
        elif self.settings.password:
            args["password"] = self.settings.password
        client.connect(**args)
        self.client = client

    def exec(self, command: str, timeout: int | None = None) -> tuple[int, str, str]:
        """Run an internally generated command and return exit code/stdout/stderr."""
        if self.client is None:
            raise RuntimeError("NAS connection is not open")
        _, stdout, stderr = self.client.exec_command(command, timeout=timeout or self.settings.ssh_timeout)
        code = stdout.channel.recv_exit_status()
        return code, stdout.read().decode("utf-8", errors="replace"), stderr.read().decode("utf-8", errors="replace")

    def sftp(self) -> Any:
        if self.client is None:
            raise RuntimeError("NAS connection is not open")
        return self.client.open_sftp()


def q(value: str) -> str:
    """Quote a path for the NAS POSIX shell."""
    import shlex

    return shlex.quote(value)


def base_path(settings: Settings, *parts: str) -> str:
    return posixpath.join(settings.deploy_dir.rstrip("/"), *parts)


def compose_command(settings: Settings, action: str) -> str:
    actions = {
        "config": "config -q",
        "up": "up -d --build --force-recreate backend frontend",
        "ps": "ps --all",
    }
    if action not in actions:
        raise ValueError("Unsupported compose action")
    return f"sudo -n docker compose -f {q(base_path(settings, 'deploy', 'docker-compose.yml'))} {actions[action]}"


def http_health(settings: Settings) -> dict[str, Any]:
    """Read the health endpoint without exposing response secrets."""
    url = settings.http_url + "/health"
    request = urllib.request.Request(url, headers={"User-Agent": "xinye-nas-deploy-mcp/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=settings.ssh_timeout) as response:
            body = response.read(2000).decode("utf-8", errors="replace")
            try:
                payload: Any = json.loads(body)
            except json.JSONDecodeError:
                payload = body
            return {"ok": True, "status_code": response.status, "url": url, "response": payload}
    except urllib.error.HTTPError as exc:
        return {"ok": False, "status_code": exc.code, "url": url, "error": str(exc)}
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return {"ok": False, "url": url, "error": str(exc)}


def local_build(settings: Settings) -> dict[str, Any]:
    """Build the frontend before deployment and return bounded output."""
    frontend = settings.project_root / "frontend"
    if not (frontend / "package.json").is_file():
        raise FileNotFoundError(f"Frontend project not found: {frontend}")
    pnpm = settings.pnpm_bin or shutil.which("pnpm.cmd") or shutil.which("pnpm")
    if not pnpm:
        raise RuntimeError("pnpm was not found; set PNPM_BIN to the pnpm executable")
    process = subprocess.run(
        [pnpm, "build"], cwd=frontend, text=True, capture_output=True,
        timeout=settings.build_timeout, check=False,
    )
    output = clip((process.stdout or "") + ("\n" + process.stderr if process.stderr else ""))
    if process.returncode != 0:
        raise RuntimeError(f"Frontend build failed (exit {process.returncode})\n{output}")
    return {"command": f"{pnpm} build", "output": output}


def local_payload(settings: Settings) -> dict[str, Path]:
    """Return the exact local directories allowed into a release."""
    payload = {
        "dist": settings.project_root / "frontend" / "dist",
        "backend/app": settings.project_root / "backend" / "app",
        "deploy": settings.project_root / "deploy",
    }
    missing = [f"{name}: {path}" for name, path in payload.items() if not path.is_dir()]
    if missing:
        raise FileNotFoundError("Release directories missing: " + "; ".join(missing))
    return payload


def remote_mkdir(sftp: Any, directory: str) -> None:
    parts = directory.strip("/").split("/")
    current = ""
    for part in parts:
        current += "/" + part
        try:
            sftp.stat(current)
        except OSError:
            sftp.mkdir(current)


def upload_directory(sftp: Any, local_dir: Path, remote_dir: str, skip_names: set[str] | None = None) -> int:
    """Upload a directory tree through SFTP and return the file count."""
    skip_names = skip_names or set()
    remote_mkdir(sftp, remote_dir)
    count = 0
    for path in local_dir.rglob("*"):
        if path.name in skip_names:
            continue
        target = posixpath.join(remote_dir, path.relative_to(local_dir).as_posix())
        if path.is_dir():
            remote_mkdir(sftp, target)
        elif path.is_file():
            remote_mkdir(sftp, posixpath.dirname(target))
            sftp.put(str(path), target)
            count += 1
    return count


def release_names() -> tuple[str, str]:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
    token = uuid.uuid4().hex[:8]
    return f".mcp-staging-{stamp}-{token}", f".backup-mcp-{stamp}-{token}"


def create_backup(settings: Settings, client: NasClient, prefix: str = ".backup-mcp") -> str:
    """Create a timestamped deployment-file backup, excluding Docker volumes."""
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
    name = f"{prefix}-{stamp}-{uuid.uuid4().hex[:8]}"
    base = q(settings.deploy_dir)
    target = q(base_path(settings, name))
    command = f"""set -eu
mkdir -p {target} {target}/backend
for item in deploy dist; do
  if [ -d {base}/$item ]; then cp -a {base}/$item {target}/$item; fi
done
if [ -d {base}/backend/app ]; then cp -a {base}/backend/app {target}/backend/app; fi
printf '%s' {q(name)}
"""
    code, stdout, stderr = client.exec(command)
    if code != 0:
        raise RuntimeError(f"NAS backup failed\n{clip(stderr or stdout)}")
    return stdout.strip() or name


def apply_release(settings: Settings, client: NasClient, staging_name: str, backup_name: str) -> dict[str, Any]:
    """Replace release files, validate Compose, recreate services, and restore on failure."""
    base = q(settings.deploy_dir)
    staging = q(base_path(settings, staging_name))
    backup = q(base_path(settings, backup_name))
    config = compose_command(settings, "config")
    up = compose_command(settings, "up")
    script = f"""set -eu
base={base}
staging={staging}
backup={backup}
restore() {{
  rm -rf "$base/deploy" "$base/dist" "$base/backend/app"
  [ -d "$backup/deploy" ] && cp -a "$backup/deploy" "$base/deploy" || true
  [ -d "$backup/dist" ] && cp -a "$backup/dist" "$base/dist" || true
  [ -d "$backup/backend/app" ] && mkdir -p "$base/backend" && cp -a "$backup/backend/app" "$base/backend/app" || true
}}
mkdir -p "$base/backend"
rm -rf "$base/deploy" "$base/dist" "$base/backend/app"
mv "$staging/deploy" "$base/deploy"
mv "$staging/dist" "$base/dist"
mv "$staging/backend/app" "$base/backend/app"
if [ -f "$backup/deploy/.env" ] && [ ! -f "$base/deploy/.env" ]; then cp "$backup/deploy/.env" "$base/deploy/.env"; fi
if ! {config}; then restore; rm -rf "$staging"; exit 20; fi
if ! {up}; then restore; {up} || true; rm -rf "$staging"; exit 21; fi
rm -rf "$staging"
printf 'release applied'
"""
    code, stdout, stderr = client.exec(script, timeout=max(settings.ssh_timeout, 600))
    if code != 0:
        raise RuntimeError(f"NAS release failed and previous files were restored\n{clip(stderr or stdout)}")
    return {"output": clip(stdout), "backup": backup_name}


def rollback_release(settings: Settings, client: NasClient, backup_name: str) -> dict[str, Any]:
    """Restore a validated backup and recreate services with failure recovery."""
    if not BACKUP_PATTERN.fullmatch(backup_name):
        raise ValueError("backup_name must be a .backup-* directory name")
    recovery = create_backup(settings, client, prefix=".backup-mcp-before-rollback")
    base = q(settings.deploy_dir)
    selected = q(base_path(settings, backup_name))
    current = q(base_path(settings, recovery))
    config = compose_command(settings, "config")
    up = compose_command(settings, "up")
    script = f"""set -eu
base={base}
selected={selected}
current={current}
restore_current() {{
  rm -rf "$base/deploy" "$base/dist" "$base/backend/app"
  [ -d "$current/deploy" ] && cp -a "$current/deploy" "$base/deploy" || true
  [ -d "$current/dist" ] && cp -a "$current/dist" "$base/dist" || true
  [ -d "$current/backend/app" ] && mkdir -p "$base/backend" && cp -a "$current/backend/app" "$base/backend/app" || true
}}
test -f "$selected/deploy/docker-compose.yml"
test -d "$selected/dist"
test -d "$selected/backend/app"
rm -rf "$base/deploy" "$base/dist" "$base/backend/app"
cp -a "$selected/deploy" "$base/deploy"
cp -a "$selected/dist" "$base/dist"
mkdir -p "$base/backend"
cp -a "$selected/backend/app" "$base/backend/app"
if ! {config}; then restore_current; exit 30; fi
if ! {up}; then restore_current; {up} || true; exit 31; fi
printf 'rollback applied'
"""
    code, stdout, stderr = client.exec(script, timeout=max(settings.ssh_timeout, 600))
    if code != 0:
        raise RuntimeError(f"NAS rollback failed and current files were restored\n{clip(stderr or stdout)}")
    return {"output": clip(stdout), "recovery_backup": recovery}


def tool_health() -> dict[str, Any]:
    settings = Settings.from_env()
    result: dict[str, Any] = {"target": settings.host or "(not configured)", "http": http_health(settings)}
    try:
        with NasClient(settings) as client:
            code, stdout, stderr = client.exec("printf connected")
            result["ssh"] = {"ok": code == 0, "output": clip(stdout), "error": clip(stderr)}
    except Exception as exc:
        result["ssh"] = {"ok": False, "error": str(exc)}
    result["ok"] = bool(result["http"].get("ok")) and bool(result["ssh"].get("ok"))
    return result


def tool_status() -> dict[str, Any]:
    settings = Settings.from_env()
    with NasClient(settings) as client:
        code, stdout, stderr = client.exec(compose_command(settings, "ps"))
    return {"ok": code == 0, "exit_code": code, "output": clip(stdout), "error": clip(stderr)}


def tool_logs(service: str, tail: int) -> dict[str, Any]:
    settings = Settings.from_env()
    if service not in SERVICE_NAMES:
        raise ValueError("service must be backend, frontend, or all")
    tail = max(1, min(int(tail), 200))
    services = "backend frontend" if service == "all" else service
    command = f"sudo -n docker compose -f {q(base_path(settings, 'deploy', 'docker-compose.yml'))} logs --tail={tail} {services}"
    with NasClient(settings) as client:
        code, stdout, stderr = client.exec(command, timeout=max(settings.ssh_timeout, 60))
    return {"ok": code == 0, "exit_code": code, "output": clip(stdout), "error": clip(stderr)}


def tool_backup() -> dict[str, Any]:
    settings = Settings.from_env()
    with NasClient(settings) as client:
        name = create_backup(settings, client)
    return {"ok": True, "backup_name": name, "backup_path": base_path(settings, name), "data_volume_unchanged": True}


def tool_deploy(confirm: bool) -> dict[str, Any]:
    settings = Settings.from_env()
    plan = {
        "target": f"{settings.host}:{settings.ssh_port}",
        "deploy_dir": settings.deploy_dir,
        "actions": ["pnpm build", "upload dist/backend/app/deploy", "create backup", "compose config", "recreate backend/frontend", "HTTP health check"],
        "data_volume_unchanged": True,
    }
    if not confirm:
        return {"ok": True, "requires_confirmation": True, "plan": plan, "message": "Preview only. Call nas_deploy with confirm=true to execute."}
    build = local_build(settings)
    payload = local_payload(settings)
    staging_name, _ = release_names()
    with NasClient(settings) as client:
        try:
            sftp = client.sftp()
            try:
                staging_dir = base_path(settings, staging_name)
                for name, local_dir in payload.items():
                    skip = {".env"} if name == "deploy" else set()
                    upload_directory(sftp, local_dir, posixpath.join(staging_dir, name), skip_names=skip)
            finally:
                sftp.close()
            backup_name = create_backup(settings, client)
            apply_result = apply_release(settings, client, staging_name, backup_name)
        except Exception:
            client.exec(f"rm -rf {q(base_path(settings, staging_name))}")
            raise
    health = http_health(settings)
    return {"ok": bool(health.get("ok")), "plan": plan, "build": build, "backup_name": backup_name, "release": apply_result, "health": health}


def tool_rollback(backup_name: str, confirm: bool) -> dict[str, Any]:
    settings = Settings.from_env()
    if not BACKUP_PATTERN.fullmatch(backup_name):
        raise ValueError("backup_name must be a .backup-* directory name")
    if not confirm:
        return {"ok": True, "requires_confirmation": True, "backup_name": backup_name, "message": "Preview only. Call nas_rollback with confirm=true to execute."}
    with NasClient(settings) as client:
        result = rollback_release(settings, client, backup_name)
    health = http_health(settings)
    return {"ok": bool(health.get("ok")), "backup_name": backup_name, "rollback": result, "health": health}
