import os
import unittest
from unittest.mock import patch

from nas_deploy_mcp.core import Settings, tool_deploy, tool_rollback


class CoreValidationTests(unittest.TestCase):
    def test_settings_requires_connection_credentials(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ValueError):
                Settings.from_env().validate()

    def test_deploy_defaults_to_preview(self):
        with patch.dict(os.environ, {"NAS_HOST": "nas", "NAS_USERNAME": "operator", "NAS_PASSWORD": "secret"}, clear=True):
            result = tool_deploy(False)
        self.assertTrue(result["requires_confirmation"])
        self.assertIn("pnpm build", result["plan"]["actions"])

    def test_rollback_rejects_path_traversal(self):
        with self.assertRaises(ValueError):
            tool_rollback("../../etc", False)


if __name__ == "__main__":
    unittest.main()

